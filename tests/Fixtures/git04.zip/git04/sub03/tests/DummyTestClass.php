<?php
class DummyTestClass1 extends \PHPUnit_Framework_TestCase
{
    public function test_dummy1()
    {
        self::assertTrue(true);
    }

    public function test_dummy2()
    {
        self::assertTrue(true);
    }

    public function test_dummy3()
    {
        self::assertTrue(true);
    }

    public function test_dummy4()
    {
        self::assertTrue(true);
    }

    public function test_dummy5()
    {
        self::assertTrue(true);
    }
}
